var searchData=
[
  ['name',['name',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#aadb47ae43058c90989eda5dd4b3f2073',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]]
];
