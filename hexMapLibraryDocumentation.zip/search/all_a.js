var searchData=
[
  ['removeinvalidcoordinates_3c_20t_20_3e',['RemoveInvalidCoordinates&lt; T &gt;',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a2648195f51cff965467d14a5d252c317',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]],
  ['rotate60degreeclockwise',['Rotate60DegreeClockwise',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex.html#aa893ac78b29a6e49f9103e0fe257214d',1,'Wunderwunsch::HexGridSimplified::Hex']]],
  ['rotate60degreecounterclockwise',['Rotate60DegreeCounterClockwise',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex.html#aefef611892aa16bfb2a87e6ecd4b61f1',1,'Wunderwunsch::HexGridSimplified::Hex']]],
  ['roundcubecoordinate',['RoundCubeCoordinate',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_utility.html#a1c2f2091fe9b5526d3341f893abbfa9a',1,'Wunderwunsch::HexGridSimplified::HexUtility']]]
];
