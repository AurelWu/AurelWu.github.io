var searchData=
[
  ['offsetcoordtocartesiancoord',['OffsetCoordToCartesianCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#a9ca98e1b9e8b73f1e6dd16eb84ac6b6f',1,'Wunderwunsch::HexGridSimplified::HexConverter']]],
  ['offsetcoordtocubecoord',['OffsetCoordToCubeCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#a29b0c64be25639aec45fe3492a3e1550',1,'Wunderwunsch::HexGridSimplified::HexConverter']]]
];
