var searchData=
[
  ['wrapsaround',['wrapsAround',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a91858cc8ffead11cc7da5ce18ac7e265',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]]
];
