var searchData=
[
  ['hexmap',['HexMap',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map.html#aa23d702b4dc61fd36d2f3c038cec12e1',1,'Wunderwunsch.HexGridSimplified.HexMap.HexMap()'],['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map.html#af1ab88e0c9bfdbfd32db2ff630ed461d',1,'Wunderwunsch.HexGridSimplified.HexMap.HexMap(Dictionary&lt; Vector3Int, int &gt; indexByPosition, string name, bool createEdges)']]],
  ['hexmapbase',['HexMapBase',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a0d37774cb898feb0010eba97d3679155',1,'Wunderwunsch.HexGridSimplified.HexMapBase.HexMapBase()'],['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a46bfb224e0042ff87db5ee051e82091d',1,'Wunderwunsch.HexGridSimplified.HexMapBase.HexMapBase(Dictionary&lt; Vector3Int, int &gt; IndexByPosition, string name, bool createEdgePositions)']]],
  ['hexmaprectangularhorizontalperiodic',['HexMapRectangularHorizontalPeriodic',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_rectangular_horizontal_periodic.html#a290ee6f7e63d29c3d79c251cbe86c3ae',1,'Wunderwunsch::HexGridSimplified::HexMapRectangularHorizontalPeriodic']]]
];
