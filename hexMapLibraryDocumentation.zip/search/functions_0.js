var searchData=
[
  ['calculatemapboundingboxandcenter',['CalculateMapBoundingBoxAndCenter',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a630365faba5d633d079ffd14e24e036f',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]],
  ['cartesiancoordtoclosestedgecoord',['CartesianCoordToClosestEdgeCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#a9a602c9de29f7d3efc5fb03104eb27a8',1,'Wunderwunsch::HexGridSimplified::HexConverter']]],
  ['cartesiancoordtocubecoord',['CartesianCoordToCubeCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#a4f687f5c1f3984e471f57dd1bc89e272',1,'Wunderwunsch::HexGridSimplified::HexConverter']]],
  ['cartesiancoordtooffsetcoord',['CartesianCoordToOffsetCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#a75d22e6b18f7c37c6f2467df92d77405',1,'Wunderwunsch::HexGridSimplified::HexConverter']]],
  ['clamptoclosestvalidedgecoordinate',['ClampToClosestValidEdgeCoordinate',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a3e1da081ea0611ce597eeb3f611cb5a4',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]],
  ['clamptoclosestvalidtilecoordinate',['ClampToClosestValidTileCoordinate',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a410a88360ebaa6abd56fd39401cd637b',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]],
  ['coordinateisonmap',['CoordinateIsOnMap',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#acda3cdf38404a030f3e5fe14acf53e24',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]],
  ['createedgeindex',['CreateEdgeIndex',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#ab7aae351f6aa5b4c4598a11fc6ac02ae',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]],
  ['createedges',['CreateEdges',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map.html#a284678987727f1dac9775697b02ba5a5',1,'Wunderwunsch::HexGridSimplified::HexMap']]],
  ['createhexagonalshapedmap',['CreateHexagonalShapedMap',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_map_shape.html#a1f8c6e39966d31546bbe0e8ea21cade0',1,'Wunderwunsch::HexGridSimplified::MapShape']]],
  ['createrectangularshapedmap',['CreateRectangularShapedMap',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_map_shape.html#a01909be6affa19bc51de08aa2d1019b2',1,'Wunderwunsch::HexGridSimplified::MapShape']]],
  ['createrectangularshapedmapoddrowsoneshorter',['CreateRectangularShapedMapOddRowsOneShorter',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_map_shape.html#a27811f989c7886d9a929f661b0287967',1,'Wunderwunsch::HexGridSimplified::MapShape']]],
  ['createtriangularshapedmap',['CreateTriangularShapedMap',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_map_shape.html#a8b79087a91d43e5ac2bc34d9b7aa8617',1,'Wunderwunsch::HexGridSimplified::MapShape']]],
  ['cubecoordtocartesiancoord',['CubeCoordToCartesianCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#abc077bb130f7c2e294279b746c9ab5fa',1,'Wunderwunsch::HexGridSimplified::HexConverter']]],
  ['cubecoordtooffsetcoord',['CubeCoordToOffsetCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_converter.html#af9fa5e6fbf9fb314eee5d83808ecbc29',1,'Wunderwunsch::HexGridSimplified::HexConverter']]]
];
