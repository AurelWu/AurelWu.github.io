var searchData=
[
  ['offsetcoord',['OffsetCoord',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_mouse.html#a6d698c299792114058aaa8d3f843dafc',1,'Wunderwunsch::HexGridSimplified::HexMouse']]],
  ['offsetcoordraw',['OffsetCoordRaw',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_mouse.html#a6749bfde614567c70d3ad8bd901c4675',1,'Wunderwunsch::HexGridSimplified::HexMouse']]]
];
