var searchData=
[
  ['name',['Name',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#a608ba65421a00cab9dc1bf10ad9486b6',1,'Wunderwunsch.HexGridSimplified.HexMapBase.Name()'],['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#aadb47ae43058c90989eda5dd4b3f2073',1,'Wunderwunsch.HexGridSimplified.HexMapBase.name()']]],
  ['normalizedposition',['NormalizedPosition',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_map_element.html#aba6c41183c1461a1efc4ade12ebba4d4',1,'Wunderwunsch::HexGridSimplified::MapElement']]]
];
