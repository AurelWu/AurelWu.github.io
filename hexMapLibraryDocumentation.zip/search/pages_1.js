var searchData=
[
  ['minimal_20example_201_3a_20creating_20a_20rectangular_20shaped_20map_20_2c_20displaying_20the_20mouse_20position_20and_20changing_20tiles_20on_20click',['Minimal Example 1: Creating a rectangular shaped map , displaying the mouse position and changing tiles on click',['../_min_ex1.html',1,'index']]]
];
