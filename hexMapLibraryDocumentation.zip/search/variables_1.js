var searchData=
[
  ['mapsize',['mapSize',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_rectangular_horizontal_periodic.html#ad017ca35a126a4e21a55a3c99addc258',1,'Wunderwunsch::HexGridSimplified::HexMapRectangularHorizontalPeriodic']]]
];
