var searchData=
[
  ['wrapsaround',['WrapsAround',['../class_wunderwunsch_1_1_hex_grid_simplified_1_1_hex_map_base.html#aac57b6ce32bf1ad8dd72e17f7bc6bc4c',1,'Wunderwunsch::HexGridSimplified::HexMapBase']]]
];
